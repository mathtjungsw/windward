# 바람의 항로 게임 안내 · JPG 7장

상태: 최종 구현 수치 대조 완료

- [게임 시작](01-start.jpg)
- [조작 방법](02-controls.jpg)
- [교역과 보급](03-trade-supplies.jpg)
- [20단계 선박과 선단](04-ships-fleet.jpg)
- [탐험과 수집](05-exploration-collection.jpg)
- [선장과 랭킹](06-captains-rankings.jpg)
- [구조와 저장](07-rescue-save.jpg)

- 크기: 장당 1800×2550 픽셀, JPG.
- 원고: GUIDE_TEXT.md.
- 생성기: ../../tools/build-player-guide.py.
- 게임: https://mathtjungsw.github.io/windward/
- 생성 명령: `python tools/build-player-guide.py --final` (현재 실제 규칙 검사를 통과해야 생성).
- 그림은 자체 제작 원본 SVG와 안내용 도형을 사용했다. 게임 화면을 캡처한 것이 아니다.
- 전체 7장 JPG의 본문 영역·한국어·그림·QR과 layout-check.json의 내용 경계를 검토했다.
